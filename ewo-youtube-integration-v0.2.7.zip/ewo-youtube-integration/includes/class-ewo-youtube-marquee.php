<?php
/**
 * Frontend YouTube video marquee.
 *
 * @package EWO_YouTube_Integration
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders latest long-form YouTube videos.
 */
class EWO_YouTube_Marquee {
	/**
	 * Shortcode tag.
	 */
	const SHORTCODE = 'ewo_youtube_marquee';

	/**
	 * Shortcode tag for the full videos archive grid.
	 */
	const ARCHIVE_SHORTCODE = 'ewo_youtube_videos';

	/**
	 * Frontend style handle.
	 */
	const STYLE_HANDLE = 'ewo-youtube-marquee';

	/**
	 * Frontend carousel script handle.
	 */
	const SCRIPT_HANDLE = 'ewo-youtube-carousel';

	/**
	 * Initialize hooks.
	 */
	public function init() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_shortcode( self::SHORTCODE, array( $this, 'render_shortcode' ) );
		add_shortcode( self::ARCHIVE_SHORTCODE, array( $this, 'render_archive_shortcode' ) );
	}

	/**
	 * Register frontend assets.
	 */
	public function register_assets() {
		wp_register_style(
			self::STYLE_HANDLE,
			EWO_YOUTUBE_INTEGRATION_URL . 'assets/css/youtube-marquee.css',
			array(),
			EWO_YOUTUBE_INTEGRATION_VERSION
		);

		wp_register_script(
			self::SCRIPT_HANDLE,
			EWO_YOUTUBE_INTEGRATION_URL . 'assets/js/youtube-carousel.js',
			array(),
			EWO_YOUTUBE_INTEGRATION_VERSION,
			true
		);
	}

	/**
	 * Render shortcode output.
	 *
	 * @return string
	 */
	public function render_shortcode() {
		return $this->render();
	}

	/**
	 * Render the single-feature latest-videos slider.
	 *
	 * @return string
	 */
	public function render() {
		$videos = $this->get_videos();

		if ( empty( $videos ) ) {
			return '';
		}

		if ( ! wp_style_is( self::STYLE_HANDLE, 'registered' ) ) {
			$this->register_assets();
		}

		wp_enqueue_style( self::STYLE_HANDLE );
		wp_enqueue_script( self::SCRIPT_HANDLE );

		ob_start();
		?>
		<section class="ewo-youtube-marquee ewo-youtube-feature" data-ewo-feature aria-label="<?php esc_attr_e( 'Latest EWO YouTube videos', 'ewo-youtube-integration' ); ?>">
			<div class="ewo-youtube-marquee__header">
				<p class="ewo-youtube-marquee__kicker"><?php esc_html_e( 'Video Intelligence', 'ewo-youtube-integration' ); ?></p>
				<h2><?php esc_html_e( 'Latest Strategic Briefings', 'ewo-youtube-integration' ); ?></h2>
			</div>
			<div class="ewo-youtube-feature__stage">
				<button class="ewo-youtube-feature__arrow ewo-youtube-feature__arrow--prev" type="button" aria-label="<?php esc_attr_e( 'Previous video', 'ewo-youtube-integration' ); ?>">
					<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>
				</button>
				<div class="ewo-youtube-feature__viewport">
					<div class="ewo-youtube-feature__track">
						<?php
						foreach ( $videos as $video ) {
							$this->render_feature_slide( $video );
						}
						?>
					</div>
				</div>
				<button class="ewo-youtube-feature__arrow ewo-youtube-feature__arrow--next" type="button" aria-label="<?php esc_attr_e( 'Next video', 'ewo-youtube-integration' ); ?>">
					<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>
				</button>
			</div>
			<div class="ewo-youtube-feature__dots" aria-label="<?php esc_attr_e( 'Carousel pagination', 'ewo-youtube-integration' ); ?>"></div>
		</section>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render a single featured slide (image left, details right).
	 *
	 * @param WP_Post $video Video post.
	 */
	private function render_feature_slide( $video ) {
		$watch_url     = $this->get_watch_url( $video->ID );
		$thumbnail_url = $this->get_card_thumbnail_url( $video );

		$publish_date = get_the_date( '', $video );
		$title        = get_the_title( $video );
		$excerpt      = $this->get_slide_excerpt( $video );
		?>
		<article class="ewo-youtube-feature__slide">
			<div class="ewo-youtube-feature__card">
				<div class="ewo-youtube-feature__media">
					<?php if ( $thumbnail_url ) : ?>
						<img src="<?php echo esc_url( $thumbnail_url ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy">
					<?php else : ?>
						<span class="ewo-youtube-feature__placeholder" aria-hidden="true"></span>
					<?php endif; ?>
					<span class="ewo-youtube-feature__play" aria-hidden="true"></span>
				</div>
				<div class="ewo-youtube-feature__details">
					<time class="ewo-youtube-feature__date" datetime="<?php echo esc_attr( get_the_date( 'c', $video ) ); ?>"><?php echo esc_html( $publish_date ); ?></time>
					<h3 class="ewo-youtube-feature__title">
						<?php if ( $watch_url ) : ?>
							<a class="ewo-youtube-feature__link" href="<?php echo esc_url( $watch_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $title ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $title ); ?>
						<?php endif; ?>
					</h3>
					<?php if ( '' !== $excerpt ) : ?>
						<p class="ewo-youtube-feature__excerpt"><?php echo esc_html( $excerpt ); ?></p>
					<?php endif; ?>
					<?php if ( $watch_url ) : ?>
						<a class="ewo-youtube-feature__button" href="<?php echo esc_url( $watch_url ); ?>" target="_blank" rel="noopener noreferrer">
							<span aria-hidden="true">&#9654;</span> <?php esc_html_e( 'Watch Analysis', 'ewo-youtube-integration' ); ?> <span aria-hidden="true">&rarr;</span>
						</a>
					<?php endif; ?>
				</div>
			</div>
		</article>
		<?php
	}

	/**
	 * Get an optional short description for a feature slide.
	 *
	 * Uses the post excerpt or content if present; returns an empty string
	 * otherwise (the description is then omitted).
	 *
	 * @param WP_Post $video Video post.
	 * @return string
	 */
	private function get_slide_excerpt( $video ) {
		$raw = '' !== $video->post_excerpt ? $video->post_excerpt : $video->post_content;
		$raw = trim( wp_strip_all_tags( (string) $raw ) );

		if ( '' === $raw ) {
			return '';
		}

		return wp_trim_words( $raw, 30 );
	}

	/**
	 * Render the videos archive shortcode output.
	 *
	 * @return string
	 */
	public function render_archive_shortcode() {
		return $this->render_archive();
	}

	/**
	 * Render a grid of all (non-hidden) videos for the Videos page.
	 *
	 * @return string
	 */
	public function render_archive() {
		if ( ! wp_style_is( self::STYLE_HANDLE, 'registered' ) ) {
			$this->register_assets();
		}

		wp_enqueue_style( self::STYLE_HANDLE );

		$videos = $this->get_all_videos();

		ob_start();

		if ( empty( $videos ) ) {
			?>
			<p class="ewo-youtube-archive__empty"><?php esc_html_e( 'No videos have been added yet.', 'ewo-youtube-integration' ); ?></p>
			<?php
			return ob_get_clean();
		}
		?>
		<section class="ewo-youtube-archive" aria-label="<?php esc_attr_e( 'EWO YouTube videos', 'ewo-youtube-integration' ); ?>">
			<div class="ewo-youtube-archive__header">
				<p class="ewo-youtube-archive__kicker"><?php esc_html_e( 'VIDEO INTELLIGENCE', 'ewo-youtube-integration' ); ?></p>
				<h2 class="ewo-youtube-archive__title"><?php esc_html_e( 'Latest Strategic Briefings', 'ewo-youtube-integration' ); ?></h2>
				<p class="ewo-youtube-archive__subtitle"><?php esc_html_e( 'Systems-level analysis on geopolitics, energy, trade corridors, and global power shifts.', 'ewo-youtube-integration' ); ?></p>
			</div>
			<div class="ewo-youtube-archive__grid">
				<?php
				foreach ( $videos as $video ) {
					$this->render_card( $video );
				}
				?>
			</div>
		</section>
		<?php

		return ob_get_clean();
	}

	/**
	 * Get latest video posts.
	 *
	 * @return WP_Post[]
	 */
	private function get_videos() {
		$query = new WP_Query(
			array(
				'post_type'           => 'ewo_video',
				'post_status'         => 'publish',
				'posts_per_page'      => 20,
				'orderby'             => 'date',
				'order'               => 'DESC',
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);

		$videos = array();

		foreach ( $query->posts as $video ) {
			if ( $this->is_hidden_video( $video->ID ) ) {
				continue;
			}

			if ( $this->is_short_video( $video->ID ) ) {
				continue;
			}

			$videos[] = $video;

			if ( 5 === count( $videos ) ) {
				break;
			}
		}

		return $videos;
	}

	/**
	 * Get all non-hidden video posts (newest first) for the archive grid.
	 *
	 * @return WP_Post[]
	 */
	private function get_all_videos() {
		$query = new WP_Query(
			array(
				'post_type'           => 'ewo_video',
				'post_status'         => 'publish',
				'posts_per_page'      => 100,
				'orderby'             => 'date',
				'order'               => 'DESC',
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);

		$videos = array();

		foreach ( $query->posts as $video ) {
			if ( $this->is_hidden_video( $video->ID ) ) {
				continue;
			}

			$videos[] = $video;
		}

		// Honor the manual Sort Order (lower first); videos without a sort
		// order fall back to newest-first.
		usort(
			$videos,
			static function ( $a, $b ) {
				$sort_a = get_post_meta( $a->ID, 'ewo_youtube_sort_order', true );
				$sort_b = get_post_meta( $b->ID, 'ewo_youtube_sort_order', true );
				$sort_a = ( '' === $sort_a ) ? PHP_INT_MAX : (int) $sort_a;
				$sort_b = ( '' === $sort_b ) ? PHP_INT_MAX : (int) $sort_b;

				if ( $sort_a !== $sort_b ) {
					return $sort_a <=> $sort_b;
				}

				return strcmp( $b->post_date, $a->post_date );
			}
		);

		return $videos;
	}

	/**
	 * Render a single video card.
	 *
	 * @param WP_Post $video    Video post.
	 * @param bool    $is_clone Whether this is a non-interactive marquee clone.
	 */
	private function render_card( $video, $is_clone = false ) {
		$watch_url     = $this->get_watch_url( $video->ID );
		$thumbnail_url = $this->get_card_thumbnail_url( $video );
		$publish_date = get_the_date( '', $video );
		$title        = get_the_title( $video );
		$topics       = $this->get_card_topics( $video->ID );
		$tabindex     = $is_clone ? ' tabindex="-1"' : '';
		?>
		<article class="ewo-youtube-marquee__card">
			<div class="ewo-youtube-marquee__thumb">
				<?php if ( $thumbnail_url ) : ?>
					<img src="<?php echo esc_url( $thumbnail_url ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy">
				<?php else : ?>
					<span class="ewo-youtube-marquee__placeholder" aria-hidden="true"></span>
				<?php endif; ?>
			</div>
			<div class="ewo-youtube-marquee__body">
				<?php if ( ! empty( $topics ) ) : ?>
					<ul class="ewo-youtube-marquee__badges">
						<?php foreach ( $topics as $topic ) : ?>
							<li class="ewo-youtube-marquee__badge"><?php echo esc_html( $topic ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<time class="ewo-youtube-marquee__date" datetime="<?php echo esc_attr( get_the_date( 'c', $video ) ); ?>"><?php echo esc_html( $publish_date ); ?></time>
				<h3 class="ewo-youtube-marquee__title">
					<?php if ( $watch_url ) : ?>
						<a class="ewo-youtube-marquee__card-link" href="<?php echo esc_url( $watch_url ); ?>" target="_blank" rel="noopener noreferrer"<?php echo $tabindex; ?>><?php echo esc_html( $title ); ?></a>
					<?php else : ?>
						<?php echo esc_html( $title ); ?>
					<?php endif; ?>
				</h3>
				<?php if ( $watch_url ) : ?>
					<a class="ewo-youtube-marquee__button" href="<?php echo esc_url( $watch_url ); ?>" target="_blank" rel="noopener noreferrer"<?php echo $tabindex; ?>>
						<?php esc_html_e( 'Watch Analysis', 'ewo-youtube-integration' ); ?> <span aria-hidden="true">&rarr;</span>
					</a>
				<?php endif; ?>
			</div>
		</article>
		<?php
	}

	/**
	 * Get optional topic badges for a video, if topic data exists.
	 *
	 * Reads an optional comma-separated `ewo_youtube_topics` meta value and
	 * keeps only the supported topics. Returns an empty array when no topic
	 * data is present (badges are then hidden).
	 *
	 * @param int $post_id Post ID.
	 * @return string[]
	 */
	private function get_card_topics( $post_id ) {
		$raw = get_post_meta( $post_id, 'ewo_youtube_topics', true );

		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			return array();
		}

		$allowed = array( 'Geopolitics', 'Strategy', 'Energy', 'Trade', 'Economy' );
		$topics  = array();

		foreach ( explode( ',', $raw ) as $candidate ) {
			$candidate = trim( $candidate );

			foreach ( $allowed as $label ) {
				if ( 0 === strcasecmp( $candidate, $label ) ) {
					$topics[] = $label;
					break;
				}
			}
		}

		return array_values( array_unique( $topics ) );
	}

	/**
	 * Determine whether a video is hidden.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private function is_hidden_video( $post_id ) {
		return (bool) get_post_meta( $post_id, 'ewo_youtube_hidden', true );
	}

	/**
	 * Determine whether a video is marked as a Short.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private function is_short_video( $post_id ) {
		$video_type = strtolower( (string) get_post_meta( $post_id, 'ewo_youtube_video_type', true ) );

		if ( in_array( $video_type, array( 'short', 'shorts' ), true ) ) {
			return true;
		}

		$flags = array(
			get_post_meta( $post_id, 'ewo_youtube_is_short', true ),
			get_post_meta( $post_id, '_ewo_youtube_is_short', true ),
		);

		foreach ( $flags as $flag ) {
			if ( in_array( strtolower( (string) $flag ), array( '1', 'yes', 'true' ), true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get a video watch URL from supported post meta keys.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private function get_watch_url( $post_id ) {
		$meta_keys = array(
			'ewo_youtube_url',
			'_ewo_youtube_url',
			'youtube_url',
			'video_url',
		);

		foreach ( $meta_keys as $meta_key ) {
			$url = get_post_meta( $post_id, $meta_key, true );

			if ( $url ) {
				return esc_url_raw( $url );
			}
		}

		return '';
	}

	/**
	 * Resolve a working thumbnail URL for a video card.
	 *
	 * Order: featured image, then a stable YouTube thumbnail derived from the
	 * video ID (stored thumbnail URLs are often expiring/signed CDN links),
	 * then a valid stored thumbnail, otherwise empty (caller shows a
	 * placeholder rather than an empty img tag).
	 *
	 * @param WP_Post $video Video post.
	 * @return string
	 */
	private function get_card_thumbnail_url( $video ) {
		$featured = get_the_post_thumbnail_url( $video, 'large' );
		if ( $featured && $this->is_valid_image_url( $featured ) ) {
			return $featured;
		}

		$video_id = get_post_meta( $video->ID, 'ewo_youtube_video_id', true );
		if ( $video_id ) {
			return 'https://img.youtube.com/vi/' . rawurlencode( $video_id ) . '/hqdefault.jpg';
		}

		$stored = get_post_meta( $video->ID, 'ewo_youtube_thumbnail', true );
		if ( $this->is_valid_image_url( $stored ) ) {
			return esc_url_raw( $stored );
		}

		return '';
	}

	/**
	 * Validate an image URL: http(s) and a real image extension or a known image CDN.
	 *
	 * @param string $url URL.
	 * @return bool
	 */
	private function is_valid_image_url( $url ) {
		$url = trim( (string) $url );

		if ( '' === $url || 0 === stripos( $url, 'data:' ) ) {
			return false;
		}

		if ( ! preg_match( '#^https?://#i', $url ) ) {
			return false;
		}

		if ( preg_match( '#\.(jpe?g|png|gif|webp|avif)(\?.*)?$#i', $url ) ) {
			return true;
		}

		foreach ( array( 'ytimg.com', 'img.youtube.com', 'substackcdn.com', 'substack-post-media', 'amazonaws.com' ) as $host ) {
			if ( false !== stripos( $url, $host ) ) {
				return true;
			}
		}

		return false;
	}
}
